<?php
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

if(class_exists(PurlemController)) {
	$purlem = new PurlemController();
	echo $purlem->display_purl_form();
}
?>